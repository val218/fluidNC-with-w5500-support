// Copyright (c) 2024 -	Mitch Bradley
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

#pragma once

#include "VFDProtocol.h"
#include "Spindles/VFDSpindle.h"
#include <string_view>

namespace Spindles {
    namespace VFD {
        class ModbusVFD : public VFDProtocol, Configuration::Configurable {
        private:
            void scale(uint32_t& n, std::string_view scale_str, uint32_t maxRPM);
            bool set_data(std::string_view                 token,
                          std::basic_string_view<uint8_t>& response_view,
                          const char*                      name,
                          uint32_t&                        data,
                          bool                             is_big_endian);

        protected:
            void direction_command(SpindleState mode, ModbusCommand& data) override;
            void set_speed_command(uint32_t dev_speed, ModbusCommand& data) override;

            response_parser initialization_sequence(int index, ModbusCommand& data, VFDSpindle* vfd) override;
            response_parser get_current_speed(ModbusCommand& data) override;
            response_parser get_current_direction(ModbusCommand& data) override { return nullptr; };
            response_parser get_status_ok(ModbusCommand& data) override { return nullptr; }

            std::string _cw_cmd;
            std::string _ccw_cmd;
            std::string _off_cmd;
            std::string _set_rpm_cmd;
            std::string _get_min_rpm_cmd;
            std::string _get_max_rpm_cmd;
            std::string _get_rpm_cmd;

            bool use_delay_settings() const override { return _get_rpm_cmd.empty(); }
            bool safety_polling() const override { return false; }

        private:
            std::string _model;  // VFD Model name
            uint32_t*   _response_data;
            uint32_t    _minRPM = 0xffffffff;
            uint32_t    _maxRPM = 0xffffffff;

            VFDSpindle* spindle;

            bool        parser(const uint8_t* response, VFDSpindle* spindle, ModbusVFD* protocol);
            void        send_vfd_command(const std::string cmd, ModbusCommand& data, uint32_t out);
            std::string _response_format;

        public:
            ModbusVFD() {}
            ModbusVFD(const char* model) : _model(model) {}
            ModbusVFD(const char* model,
                      uint32_t    min_rpm,
                      uint32_t    max_rpm,
                      const char* cw_cmd,
                      const char* ccw_cmd,
                      const char* off_cmd,
                      const char* set_rpm_cmd,
                      const char* get_rpm_cmd,
                      const char* get_min_rpm_cmd,
                      const char* get_max_rpm_cmd) :
                _model(model), _minRPM(min_rpm), _maxRPM(max_rpm), _cw_cmd(cw_cmd), _ccw_cmd(ccw_cmd), _off_cmd(off_cmd),
                _set_rpm_cmd(set_rpm_cmd), _get_min_rpm_cmd(get_min_rpm_cmd), _get_max_rpm_cmd(get_max_rpm_cmd), _get_rpm_cmd(get_rpm_cmd) {}

            void group(Configuration::HandlerBase& handler) override {
                handler.item("model", _model);
                handler.item("min_RPM", _minRPM);
                handler.item("max_RPM", _maxRPM);
                handler.item("cw_cmd", _cw_cmd);
                handler.item("ccw_cmd", _ccw_cmd);
                handler.item("off_cmd", _off_cmd);
                handler.item("set_rpm_cmd", _set_rpm_cmd);
                handler.item("get_min_rpm_cmd", _get_min_rpm_cmd);
                handler.item("get_max_rpm_cmd", _get_max_rpm_cmd);
                handler.item("get_rpm_cmd", _get_rpm_cmd);
            }
        };
    }
}
