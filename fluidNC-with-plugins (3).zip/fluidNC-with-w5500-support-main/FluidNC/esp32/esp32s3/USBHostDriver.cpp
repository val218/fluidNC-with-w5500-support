// Copyright (c) 2026 - Algy Tynan
// Use of this source code is governed by a GPLv3 license that can be found in the LICENSE file.

#include "Platform.h"
#if MAX_N_USB_HOST

#include "USBHostDriver.h"

#include <usb/vcp.hpp>
#include <usb/vcp_ch34x.hpp>
#include <usb/vcp_cp210x.hpp>
#include <usb/vcp_ftdi.hpp>

#include "Report.h"
#include "NutsBolts.h"

bool USBHostDriver::rxCallback(const uint8_t* data, size_t data_len, void* user_arg) {
    auto* self = static_cast<USBHostDriver*>(user_arg);
    if (self->_rx_ring && data_len > 0) {
        xRingbufferSend(self->_rx_ring, data, data_len, 0);
    }
    return true;
}

void USBHostDriver::deviceEventCallback(const cdc_acm_host_dev_event_data_t* event, void* user_arg) {
    auto* self = static_cast<USBHostDriver*>(user_arg);
    switch (event->type) {
        case CDC_ACM_HOST_DEVICE_DISCONNECTED:
            self->_connected.store(false);
            log_info("USB Host: device disconnected");
            break;
        default:
            log_warn("USB Host: device event " << (int)event->type);
            break;
    }
}

void USBHostDriver::newDeviceCallback(usb_device_handle_t usb_dev) {
    const usb_device_desc_t* desc = nullptr;
    usb_host_get_device_descriptor(usb_dev, &desc);
    if (desc) {
        log_info("USB Host: device attached (VID:" << to_hex(desc->idVendor)
                 << " PID:" << to_hex(desc->idProduct) << ")");
    } else {
        log_info("USB Host: unknown device attached");
    }
}

void USBHostDriver::daemonTask(void* arg) {
    auto* self = static_cast<USBHostDriver*>(arg);
    while (!self->_shutdown_requested.load()) {
        uint32_t event_flags;
        usb_host_lib_handle_events(pdMS_TO_TICKS(500), &event_flags);
    }
    vTaskDelete(nullptr);
}

void USBHostDriver::classTask(void* arg) {
    auto* self = static_cast<USBHostDriver*>(arg);

    const cdc_acm_host_driver_config_t driver_config = {
        .driver_task_stack_size = 4096,
        .driver_task_priority   = 5,
        .xCoreID                = 1,
        .new_dev_cb             = newDeviceCallback,
    };
    esp_err_t err = cdc_acm_host_install(&driver_config);
    if (err != ESP_OK) {
        log_error("USB Host: CDC-ACM driver install failed: " << esp_err_to_name(err));
        vTaskDelete(nullptr);
        return;
    }

    using namespace esp_usb;
    VCP::register_driver<CH34x>();
    VCP::register_driver<CP210x>();
    VCP::register_driver<FT23x>();

    log_info("USB Host: waiting for device...");

    while (!self->_shutdown_requested.load()) {
        const cdc_acm_host_device_config_t dev_config = {
            .connection_timeout_ms = 500,
            .out_buffer_size       = 512,
            .in_buffer_size        = 512,
            .event_cb              = USBHostDriver::deviceEventCallback,
            .data_cb               = USBHostDriver::rxCallback,
            .user_arg              = self,
        };

        CdcAcmDevice* dev = nullptr;
        const char* dev_type = "VCP";
        try {
            dev = VCP::open(&dev_config);
        } catch (const std::exception& e) {
            log_error("USB Host: device open failed: " << e.what());
            if (self->_shutdown_requested.load()) break;
            vTaskDelay(pdMS_TO_TICKS(1000));
            continue;
        }

        // Fallback: if no VCP driver matched, try standard CDC-ACM
        if (!dev) {
            dev = new CdcAcmDevice();
            if (dev->open(CDC_HOST_ANY_VID, CDC_HOST_ANY_PID, 0, &dev_config) != ESP_OK) {
                delete dev;
                dev = nullptr;
            } else {
                dev_type = "CDC-ACM";
            }
        }
        if (!dev) {
            continue;
        }

        cdc_acm_line_coding_t line_coding = {
            .dwDTERate   = self->_baud,
            .bCharFormat = 0,
            .bParityType = 0,
            .bDataBits   = 8,
        };
        err = dev->line_coding_set(&line_coding);
        if (err != ESP_OK) {
            log_warn("USB Host: line_coding_set failed: " << esp_err_to_name(err));
        }

        dev->set_control_line_state(true, true);

        self->_vcp_dev = dev;
        self->_connected.store(true);
        log_info("USB Host: device connected (" << dev_type << "), baud " << self->_baud);

        while (self->_connected.load() && !self->_shutdown_requested.load()) {
            size_t item_size = 0;
            uint8_t* tx_data = static_cast<uint8_t*>(
                xRingbufferReceive(self->_tx_ring, &item_size, pdMS_TO_TICKS(10))
            );
            if (tx_data && item_size > 0) {
                err = dev->tx_blocking(tx_data, item_size, 100);
                vRingbufferReturnItem(self->_tx_ring, tx_data);

                if (err == ESP_ERR_TIMEOUT) {
                    // device busy
                } else if (err == ESP_ERR_INVALID_STATE) {
                    log_info("USB Host: device gone during TX");
                    break;
                } else if (err != ESP_OK) {
                    log_warn("USB Host: TX error: " << esp_err_to_name(err));
                }
            }
        }

        self->flushRx();
        self->flushTx();
        self->clearPeekCache();
        self->_vcp_dev = nullptr;
        delete dev;
        if (!self->_shutdown_requested.load()) {
            log_info("USB Host: waiting for reconnect...");
        }
    }
    vTaskDelete(nullptr);
}

void USBHostDriver::init(uint32_t baud) {
    _baud = baud;

    _rx_ring = xRingbufferCreate(RX_BUF_SIZE, RINGBUF_TYPE_BYTEBUF);
    if (!_rx_ring) {
        log_error("USB Host: RX ring buffer creation failed");
        return;
    }
    _tx_ring = xRingbufferCreate(TX_BUF_SIZE, RINGBUF_TYPE_BYTEBUF);
    if (!_tx_ring) {
        log_error("USB Host: TX ring buffer creation failed");
        vRingbufferDelete(_rx_ring);
        _rx_ring = nullptr;
        return;
    }

    const usb_host_config_t host_config = {
        .skip_phy_setup = false,
        .intr_flags     = ESP_INTR_FLAG_LEVEL1,
    };
    esp_err_t err = usb_host_install(&host_config);
    if (err != ESP_OK) {
        log_error("USB Host: usb_host_install failed: " << esp_err_to_name(err));
        vRingbufferDelete(_rx_ring);
        vRingbufferDelete(_tx_ring);
        _rx_ring = nullptr;
        _tx_ring = nullptr;
        return;
    }

    xTaskCreatePinnedToCore(daemonTask, "usb_daemon", 4096, this, 2, &_daemon_task_handle, 1);
    xTaskCreatePinnedToCore(classTask, "usb_class", 4096, this, 3, &_class_task_handle, 1);

    log_info("USB Host: stack initialised");
}

void USBHostDriver::shutdown() {
    _connected.store(false);
    _shutdown_requested.store(true);

    for (int i = 0; i < 20; i++) {
        bool daemon_done = !_daemon_task_handle || eTaskGetState(_daemon_task_handle) == eDeleted;
        bool class_done  = !_class_task_handle  || eTaskGetState(_class_task_handle)  == eDeleted;
        if (daemon_done && class_done) {
            break;
        }
        vTaskDelay(pdMS_TO_TICKS(100));
    }

    // Tasks self-delete via vTaskDelete(nullptr) on exit.
    // Just null the handles here.
    _daemon_task_handle = nullptr;
    _class_task_handle = nullptr;
    cdc_acm_host_uninstall();
    usb_host_uninstall();
    if (_rx_ring) {
        vRingbufferDelete(_rx_ring);
        _rx_ring = nullptr;
    }
    if (_tx_ring) {
        vRingbufferDelete(_tx_ring);
        _tx_ring = nullptr;
    }
}

int USBHostDriver::read() {
    if (_has_peek) {
        _has_peek = false;
        int b = _peek_byte;
        _peek_byte = -1;
        return b;
    }
    if (!_rx_ring) {
        return -1;
    }
    size_t item_size = 0;
    uint8_t* item = static_cast<uint8_t*>(
        xRingbufferReceiveUpTo(_rx_ring, &item_size, 0, 1)
    );
    if (!item || item_size == 0) {
        return -1;
    }
    uint8_t byte = item[0];
    vRingbufferReturnItem(_rx_ring, item);
    return byte;
}

int USBHostDriver::peek() {
    if (_has_peek) {
        return _peek_byte;
    }
    if (!_rx_ring) {
        return -1;
    }
    size_t item_size = 0;
    uint8_t* item = static_cast<uint8_t*>(
        xRingbufferReceiveUpTo(_rx_ring, &item_size, 0, 1)
    );
    if (!item || item_size == 0) {
        return -1;
    }
    _peek_byte = item[0];
    _has_peek  = true;
    vRingbufferReturnItem(_rx_ring, item);
    return _peek_byte;
}

int USBHostDriver::available() {
    if (!_rx_ring) {
        return 0;
    }
    return (_has_peek ? 1 : 0) + (RX_BUF_SIZE - xRingbufferGetCurFreeSize(_rx_ring));
}

int USBHostDriver::rx_buffer_available() {
    if (!_rx_ring) {
        return 0;
    }
    return xRingbufferGetCurFreeSize(_rx_ring);
}

void USBHostDriver::flushRx() {
    clearPeekCache();
    if (!_rx_ring) {
        return;
    }
    size_t item_size;
    while (void* item = xRingbufferReceive(_rx_ring, &item_size, 0)) {
        vRingbufferReturnItem(_rx_ring, item);
    }
}

void USBHostDriver::flushTx() {
    if (!_tx_ring) {
        return;
    }
    size_t item_size;
    while (void* item = xRingbufferReceive(_tx_ring, &item_size, 0)) {
        vRingbufferReturnItem(_tx_ring, item);
    }
}

size_t USBHostDriver::write(uint8_t c) {
    return write(&c, 1);
}

size_t USBHostDriver::write(const uint8_t* buf, size_t len) {
    if (!_connected.load() || !_tx_ring) {
        return 0;
    }
    if (xRingbufferSend(_tx_ring, buf, len, 0) == pdTRUE) {
        return len;
    }
    return 0;
}

#endif // MAX_N_USB_HOST
